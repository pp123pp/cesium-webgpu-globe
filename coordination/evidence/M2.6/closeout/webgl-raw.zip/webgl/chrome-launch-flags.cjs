const childProcess = require('node:child_process');
const originalSpawn = childProcess.spawn;
childProcess.spawn = function (command, args, options) {
  if (command === process.env.CHROME_BIN) {
    args = ['--no-sandbox', '--enable-webgl', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', ...args];
  }
  return originalSpawn.call(this, command, args, options);
};
